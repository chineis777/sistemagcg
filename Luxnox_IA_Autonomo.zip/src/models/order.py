# src/models/order.py

import enum
from datetime import datetime
from sqlalchemy.dialects.mysql import DECIMAL

from src.models.user import db, User # Import db instance and User model

class OrderStatus(enum.Enum):
    PENDING = "PENDING"
    PROCESSING = "PROCESSING"
    DELIVERED = "DELIVERED"
    COMPLETED = "COMPLETED" # Final state after delivery and payment
    CANCELLED = "CANCELLED"

class PaymentStatus(enum.Enum):
    PENDING = "PENDING"
    PAID = "PAID"
    FAILED = "FAILED"

class Order(db.Model):
    __tablename__ = "orders"

    id = db.Column(db.Integer, primary_key=True)
    # Assuming an order involves a customer placing it, an autopeça fulfilling it, 
    # and potentially a mechanic who facilitated it (earning commission).
    customer_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    autpeca_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    mechanic_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True) # Mechanic who gets commission
    
    total_amount = db.Column(DECIMAL(precision=10, scale=2), nullable=False)
    # Store calculated commission amount directly for simplicity, or calculate on the fly
    commission_amount = db.Column(DECIMAL(precision=10, scale=2), nullable=True, default=0.00)
    
    status = db.Column(db.Enum(OrderStatus), nullable=False, default=OrderStatus.PENDING)
    payment_status = db.Column(db.Enum(PaymentStatus), nullable=False, default=PaymentStatus.PENDING)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    customer = db.relationship("User", foreign_keys=[customer_id])
    autpeca = db.relationship("User", foreign_keys=[autpeca_id])
    mechanic = db.relationship("User", foreign_keys=[mechanic_id])

    # Link back to transactions related to this order (e.g., SALE_IN for autopeça)
    # transactions = db.relationship("Transaction", backref="order", lazy=True)

    def __repr__(self):
        return f"<Order {self.id} - Customer: {self.customer_id} - Status: {self.status.value}>"

# Note: OrderItem model would also be needed for detailed commission calculation based on items.
# For now, using a pre-calculated commission_amount on the Order model.

