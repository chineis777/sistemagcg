# src/models/mechanic.py

from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.dialects.mysql import JSON
from datetime import datetime

# Supondo que 'db' seja instanciado em main.py e importado aqui se necessário,
# ou que os modelos sejam definidos e depois associados ao 'db' em main.py.
# Por enquanto, vamos definir as classes e depois ajustamos a inicialização do db.

db = SQLAlchemy() # Placeholder, será o db da aplicação principal

class VehicleChecklist(db.Model):
    __tablename__ = 'vehicle_checklists'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    # vehicle_id - Para MVP, vamos armazenar dados do veículo diretamente
    plate_number = db.Column(db.String(20), unique=True, nullable=False)
    brand = db.Column(db.String(100), nullable=True)
    model = db.Column(db.String(100), nullable=True)
    year = db.Column(db.Integer, nullable=True)
    color = db.Column(db.String(50), nullable=True)
    
    customer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    mechanic_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    entry_datetime = db.Column(db.DateTime, default=datetime.utcnow)
    fuel_level = db.Column(db.String(50), nullable=True)
    current_km = db.Column(db.Integer, nullable=True)
    customer_notes = db.Column(db.Text, nullable=True)
    inspection_items = db.Column(JSON, nullable=True) # Ex: {"exterior_farois": "ok", "interior_buzina": "defeito"}
    customer_belongings = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(50), default='Aberto') # Aberto, Em Orçamento, Finalizado

    customer = db.relationship('User', foreign_keys=[customer_id], backref=db.backref('customer_checklists', lazy='dynamic'))
    mechanic = db.relationship('User', foreign_keys=[mechanic_id], backref=db.backref('mechanic_checklists', lazy='dynamic'))

    def __repr__(self):
        return f'<VehicleChecklist {self.id} - {self.plate_number}>'

class Quote(db.Model):
    __tablename__ = 'quotes'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    checklist_id = db.Column(db.Integer, db.ForeignKey('vehicle_checklists.id'), nullable=True)
    # vehicle_info (JSON ou campos) - Se não houver checklist, ou para redundância.
    # Para simplificar no MVP, vamos assumir que um orçamento pode ser criado sem checklist direto,
    # mas idealmente estaria ligado a um veículo já registrado ou a um checklist.
    plate_number_if_no_checklist = db.Column(db.String(20), nullable=True) # Usar se checklist_id for NULL

    customer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    mechanic_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    quote_date = db.Column(db.Date, default=datetime.utcnow)
    expiry_date = db.Column(db.Date, nullable=True)
    
    total_parts_value = db.Column(db.Numeric(10, 2), default=0.00)
    total_labor_value = db.Column(db.Numeric(10, 2), default=0.00)
    discount_value = db.Column(db.Numeric(10, 2), default=0.00)
    total_quote_value = db.Column(db.Numeric(10, 2), default=0.00)
    
    observations = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(50), default='Pendente Aprovação Cliente') 
    # Pendente Aprovação Cliente, Aprovado, Reprovado, Em Serviço, Serviço Concluído, Cancelado
    sent_to_customer_datetime = db.Column(db.DateTime, nullable=True)

    checklist = db.relationship('VehicleChecklist', backref=db.backref('quotes', lazy='dynamic'))
    customer = db.relationship('User', foreign_keys=[customer_id], backref=db.backref('customer_quotes', lazy='dynamic'))
    mechanic = db.relationship('User', foreign_keys=[mechanic_id], backref=db.backref('mechanic_quotes', lazy='dynamic'))
    items = db.relationship('QuoteItem', backref='quote', lazy='dynamic', cascade="all, delete-orphan")

    def __repr__(self):
        return f'<Quote {self.id} - Status: {self.status}>'

    def update_totals(self):
        self.total_parts_value = sum(item.subtotal for item in self.items if item.item_type == 'part')
        self.total_labor_value = sum(item.subtotal for item in self.items if item.item_type == 'labor')
        self.total_quote_value = (self.total_parts_value + self.total_labor_value) - self.discount_value

class QuoteItem(db.Model):
    __tablename__ = 'quote_items'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    quote_id = db.Column(db.Integer, db.ForeignKey('quotes.id'), nullable=False)
    item_type = db.Column(db.Enum('part', 'labor', name='quote_item_types_enum'), nullable=False)
    
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=True) # Supondo tabela 'products'
    description = db.Column(db.String(255), nullable=False)
    quantity = db.Column(db.Integer, default=1)
    unit_price = db.Column(db.Numeric(10, 2), nullable=False)
    subtotal = db.Column(db.Numeric(10, 2), nullable=False)
    
    subject_to_change_after_disassembly = db.Column(db.Boolean, default=False)
    commission_percentage_applied = db.Column(db.Numeric(5, 2), nullable=True)
    commission_value_earned = db.Column(db.Numeric(10, 2), nullable=True)

    product = db.relationship('Product', backref=db.backref('quote_items', lazy='dynamic')) # Supondo modelo Product

    def __repr__(self):
        return f'<QuoteItem {self.id} - {self.description}>'

    def calculate_subtotal(self):
        self.subtotal = self.quantity * self.unit_price

# Para que os modelos sejam utilizáveis, eles precisam ser inicializados com a instância `db` da aplicação principal.
# Isso geralmente é feito em `main.py` ou em um arquivo `models/__init__.py`.
# Exemplo em models/__init__.py:
# from .user import User
# from .finance import Wallet, Transaction
# from .order import Order, OrderItem # Se houver
# from .mechanic import VehicleChecklist, Quote, QuoteItem
# __all__ = ['User', 'Wallet', 'Transaction', 'Order', 'OrderItem', 'VehicleChecklist', 'Quote', 'QuoteItem']

# E em main.py, após db = SQLAlchemy(app):
# from src.models.mechanic import VehicleChecklist, Quote, QuoteItem # e outros modelos
# db.create_all()

