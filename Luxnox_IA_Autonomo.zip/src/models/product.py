# src/models/product.py

from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

# Supondo que 'db' seja instanciado em main.py e importado aqui se necessário.
# Por enquanto, vamos definir as classes e depois ajustamos a inicialização do db.

db = SQLAlchemy() # Placeholder, será o db da aplicação principal

class ProductCategory(db.Model):
    __tablename__ = 'product_categories'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(150), unique=True, nullable=False)
    parent_category_id = db.Column(db.Integer, db.ForeignKey('product_categories.id'), nullable=True)
    
    parent = db.relationship('ProductCategory', remote_side=[id], backref=db.backref('subcategories', lazy='dynamic'))
    products = db.relationship('Product', backref='category', lazy='dynamic')

    def __repr__(self):
        return f'<ProductCategory {self.name}>'

class Manufacturer(db.Model):
    __tablename__ = 'manufacturers'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(150), unique=True, nullable=False)
    products = db.relationship('Product', backref='manufacturer', lazy='dynamic')

    def __repr__(self):
        return f'<Manufacturer {self.name}>'

class ProductBrand(db.Model):
    __tablename__ = 'product_brands'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(150), unique=True, nullable=False)
    products = db.relationship('Product', backref='brand', lazy='dynamic')

    def __repr__(self):
        return f'<ProductBrand {self.name}>'

class Product(db.Model):
    __tablename__ = 'products'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    code = db.Column(db.String(100), unique=True, nullable=False)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    cost_price = db.Column(db.Numeric(10, 2), nullable=False)
    sale_price = db.Column(db.Numeric(10, 2), nullable=False)
    stock_quantity = db.Column(db.Integer, nullable=False, default=0)
    
    category_id = db.Column(db.Integer, db.ForeignKey('product_categories.id'), nullable=True)
    manufacturer_id = db.Column(db.Integer, db.ForeignKey('manufacturers.id'), nullable=True)
    brand_id = db.Column(db.Integer, db.ForeignKey('product_brands.id'), nullable=True)
    # supplier_id: FK para User (Autopeça) - Adicionar se for marketplace
    
    product_line = db.Column(db.String(150), nullable=True)
    manufacturer_code = db.Column(db.String(100), nullable=True)
    ean_barcode = db.Column(db.String(100), nullable=True)
    unit_of_measure = db.Column(db.String(50), nullable=True)
    status = db.Column(db.String(50), default='active') # active, inactive, out_of_stock
    is_kit = db.Column(db.Boolean, default=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    images = db.relationship('ProductImage', backref='product', lazy='dynamic', cascade="all, delete-orphan")
    applications = db.relationship('VehicleApplication', backref='product', lazy='dynamic', cascade="all, delete-orphan")
    kit_components = db.relationship('KitComponent', foreign_keys='KitComponent.kit_product_id', backref='kit_product', lazy='dynamic', cascade="all, delete-orphan")
    component_of_kits = db.relationship('KitComponent', foreign_keys='KitComponent.component_product_id', backref='component_product', lazy='dynamic')

    def __repr__(self):
        return f'<Product {self.id} - {self.name}>'

class ProductImage(db.Model):
    __tablename__ = 'product_images'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    image_url = db.Column(db.String(500), nullable=False)
    is_primary = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return f'<ProductImage {self.image_url} for Product {self.product_id}>'

class VehicleBrand(db.Model):
    __tablename__ = 'vehicle_brands'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    models = db.relationship('VehicleModel', backref='brand', lazy='dynamic')

    def __repr__(self):
        return f'<VehicleBrand {self.name}>'

class VehicleModel(db.Model):
    __tablename__ = 'vehicle_models'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    vehicle_brand_id = db.Column(db.Integer, db.ForeignKey('vehicle_brands.id'), nullable=False)
    name = db.Column(db.String(150), nullable=False)
    # Unique constraint for (vehicle_brand_id, name)
    __table_args__ = (db.UniqueConstraint('vehicle_brand_id', 'name', name='_vehicle_brand_model_uc'),)
    applications = db.relationship('VehicleApplication', backref='vehicle_model', lazy='dynamic')

    def __repr__(self):
        return f'<VehicleModel {self.brand.name} {self.name}>'

class VehicleApplication(db.Model):
    __tablename__ = 'vehicle_applications'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    # Direct FK to VehicleModel is better than storing brand_id and model_id separately here
    vehicle_model_id = db.Column(db.Integer, db.ForeignKey('vehicle_models.id'), nullable=False)
    year_start = db.Column(db.Integer, nullable=True)
    year_end = db.Column(db.Integer, nullable=True)
    engine_details = db.Column(db.String(255), nullable=True)
    version_details = db.Column(db.String(255), nullable=True)
    notes = db.Column(db.Text, nullable=True)

    def __repr__(self):
        return f'<VehicleApplication for Product {self.product_id} on Model {self.vehicle_model_id}>'

class KitComponent(db.Model):
    __tablename__ = 'kit_components'
    kit_product_id = db.Column(db.Integer, db.ForeignKey('products.id'), primary_key=True)
    component_product_id = db.Column(db.Integer, db.ForeignKey('products.id'), primary_key=True)
    quantity = db.Column(db.Integer, nullable=False, default=1)

    def __repr__(self):
        return f'<KitComponent KitID:{self.kit_product_id} CompID:{self.component_product_id} Qty:{self.quantity}>'

# Adicionar estes modelos ao __init__.py dos models e ao db.create_all() em main.py

