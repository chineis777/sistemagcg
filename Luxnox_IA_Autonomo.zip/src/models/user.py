from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import enum
from datetime import datetime

db = SQLAlchemy()

class UserType(enum.Enum):
    CLIENTE = "Cliente"
    AUTOPECA = "Autopeça"
    ADMIN = "Admin"
    # Add other types later as needed (Mecanico, Oficina, Vendedor, Motoboy)

class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False) # Increased length for hash
    user_type = db.Column(db.Enum(UserType), nullable=False)
    name = db.Column(db.String(100), nullable=True)
    is_approved = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.TIMESTAMP, default=datetime.utcnow, nullable=False)

    # Relationships (to be added later)
    # products = db.relationship('Product', backref='autpeca', lazy=True) # For Autopeça
    # orders = db.relationship('Order', backref='client', lazy=True) # For Cliente

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f'<User {self.email}>'

# Add other models (Product, Order, OrderItem) later based on the plan

