# src/models/finance.py

import enum
from datetime import datetime
from sqlalchemy.dialects.mysql import DECIMAL
from sqlalchemy.types import JSON # Using JSON for crypto balances initially

from src.models.user import db, User # Import db instance and User model

class TransactionType(enum.Enum):
    DEPOSIT = "DEPOSIT"
    WITHDRAWAL = "WITHDRAWAL"
    COMMISSION_IN = "COMMISSION_IN"
    COMMISSION_OUT = "COMMISSION_OUT"
    SALE_IN = "SALE_IN"
    PURCHASE_OUT = "PURCHASE_OUT"
    TRANSFER_IN = "TRANSFER_IN"
    TRANSFER_OUT = "TRANSFER_OUT"
    CRYPTO_CONVERT_IN = "CRYPTO_CONVERT_IN"
    CRYPTO_CONVERT_OUT = "CRYPTO_CONVERT_OUT"
    MANUAL_ADJUST = "MANUAL_ADJUST"
    CASH_IN = "CASH_IN" # Added for cash control
    CASH_OUT = "CASH_OUT" # Added for cash control
    PAYABLE_PAID = "PAYABLE_PAID" # Added for accounts payable
    RECEIVABLE_RECEIVED = "RECEIVABLE_RECEIVED" # Added for accounts receivable

class TransactionStatus(enum.Enum):
    PENDING = "PENDING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"

class CashSessionStatus(enum.Enum):
    OPEN = "OPEN"
    CLOSED = "CLOSED"

class AccountType(enum.Enum):
    PAYABLE = "PAYABLE"
    RECEIVABLE = "RECEIVABLE"

class AccountStatus(enum.Enum):
    PENDING = "PENDING"
    PAID = "PAID"
    RECEIVED = "RECEIVED"
    OVERDUE = "OVERDUE"
    CANCELLED = "CANCELLED"

class Wallet(db.Model):
    __tablename__ = "wallets"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, unique=True)
    balance_brl = db.Column(DECIMAL(precision=10, scale=2), nullable=False, default=0.00)
    balance_crypto = db.Column(JSON, nullable=True, default={})
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship("User", backref=db.backref("wallet", uselist=False))
    transactions = db.relationship("Transaction", backref="wallet", lazy=True)

    def __repr__(self):
        return f"<Wallet {self.user_id} - BRL: {self.balance_brl}>"

class Transaction(db.Model):
    __tablename__ = "transactions"

    id = db.Column(db.Integer, primary_key=True)
    wallet_id = db.Column(db.Integer, db.ForeignKey("wallets.id"), nullable=False)
    type = db.Column(db.Enum(TransactionType), nullable=False)
    amount_brl = db.Column(DECIMAL(precision=10, scale=2), nullable=False)
    amount_crypto = db.Column(DECIMAL(precision=18, scale=8), nullable=True)
    crypto_asset = db.Column(db.String(10), nullable=True)
    description = db.Column(db.Text, nullable=True)
    related_order_id = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=True)
    related_user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    cash_session_id = db.Column(db.Integer, db.ForeignKey("cash_control_sessions.id"), nullable=True)
    account_payable_receivable_id = db.Column(db.Integer, db.ForeignKey("accounts_payable_receivable.id"), nullable=True) # Link to account
    status = db.Column(db.Enum(TransactionStatus), nullable=False, default=TransactionStatus.PENDING)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Transaction {self.id} - {self.type.value} - {self.amount_brl}>"

class CashControlSession(db.Model):
    __tablename__ = "cash_control_sessions"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    start_time = db.Column(db.DateTime, default=datetime.utcnow)
    end_time = db.Column(db.DateTime, nullable=True)
    initial_balance_brl = db.Column(DECIMAL(precision=10, scale=2), nullable=False)
    final_balance_brl = db.Column(DECIMAL(precision=10, scale=2), nullable=True)
    initial_balance_details = db.Column(JSON, nullable=True, default={})
    final_balance_details = db.Column(JSON, nullable=True)
    status = db.Column(db.Enum(CashSessionStatus), nullable=False, default=CashSessionStatus.OPEN)

    transactions = db.relationship("Transaction", backref="cash_session", lazy="dynamic")
    user = db.relationship("User")

    def __repr__(self):
        return f"<CashControlSession {self.id} - User: {self.user_id} - Status: {self.status.value}>"

class AccountsPayableReceivable(db.Model):
    __tablename__ = "accounts_payable_receivable"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False) # User responsible for this account (e.g., Autopeça)
    type = db.Column(db.Enum(AccountType), nullable=False)
    description = db.Column(db.Text, nullable=False)
    due_date = db.Column(db.Date, nullable=False)
    amount = db.Column(DECIMAL(precision=10, scale=2), nullable=False)
    status = db.Column(db.Enum(AccountStatus), nullable=False, default=AccountStatus.PENDING)
    related_user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True) # Client/Supplier
    related_order_id = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    paid_received_at = db.Column(db.DateTime, nullable=True)

    # Relationship to the transaction that settled this account
    settlement_transaction = db.relationship("Transaction", backref="settled_account", uselist=False)
    user = db.relationship("User", foreign_keys=[user_id])
    related_user = db.relationship("User", foreign_keys=[related_user_id])

    def __repr__(self):
        return f"<Account {self.id} - {self.type.value} - {self.amount} - Due: {self.due_date}>"

